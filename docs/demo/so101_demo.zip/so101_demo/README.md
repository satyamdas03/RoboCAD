# SO-101 demo: open this first

`so101_demo.zip` is the whole demo. Unzip it anywhere and open `index.html` in a browser. No server,
no network, no install. Every number on the page is read from the compiled bundle's `report.json`,
and the provenance line at the top says which bundle and which checks are shown.

## 3 minute script

1. **0:00, compiled from its own CAD.** Open `index.html`. Read the provenance line aloud: this is
   the SO-101 compiled from the STEP file exported from the SO-ARM100 repository at commit
   `a758567`, not a hand-written model. The 3D geometry is the bundle's own visual meshes,
   decimated to 533,262 triangles of the bundle's 620,093 — 86.0% — at a 3,000-triangle-per-mesh
   budget, so a browser can hold it (counted by `teardown_export/bake.py` at build time and recorded
   in the packaged README's "Mesh resolution" section; the bundle's own total comes from
   `report.json`). The budget was raised from 2,500 because at that setting the reducer overshot and
   left ~500 triangles per mesh, which is under the budget rather than near it.
2. **0:30, the seven checks.** Point at the Checks panel. Five pass, one is skipped, and
   `self_collision` **fails**: two convex hulls overlap 7.9 mm at rest. The B-rep solids touch and
   share 0.52 mm3, which is contact-scale, so MuJoCo will act on a contact the CAD does not have. The
   report carries 149 warnings, and 13 of them are parts whose hulls cover more than 3x their own
   volume (the largest, `part_081`, 28.9x); the bundle's assembly import adds 116 more of its own.
   None of this is hidden, and none of it is a passing light. `[verified: counted in
   docs/twin/so101/bundle/report.json and bundle.json]`
3. **1:00, same robot as the official model.** Comparison panel: joint axes agree within **1.05°**
   rms, worst 2.14°. Joint origins look wrong by up to 110 mm **until the zero-pose conventions are
   applied**, and then they agree at **2.50 mm median / 11.25 mm worst**. Frame-free link lengths
   agree to **1.69 mm**, which no registration can fake. See `CONVENTIONS.md`.
4. **1:30, masses with their assumptions.** Solid upper bound **1.332 kg**, print model **0.902 kg**,
   published **0.632 kg**. The print model assumes 1.2 mm walls and 0.20 infill, so printed mass is a
   range, not a measurement. The compiled body masses are printed plastic only — the 55 g servo mass
   is used in the comparison against the published model and does **not** enter the bundle's mass
   properties, so the two totals are not the same kind of number.
5. **2:00, what that does to the motors.** Torque panel: required torque for the same trajectory on
   both models, with the bundle's own 2.94 N m actuator limit drawn as a dashed line. Peak 1.26 N m
   official against 0.63 N m compiled, so neither saturates on this motion.
6. **2:20, the revision.** `diff.md` beside this file (in the repo at
   `docs/twin/so101/revision_f030/diff.md`): the same pipeline recompiled at
   0.30 infill against the frozen bundle's 0.20, diffed per link on the same link names from
   `robot.joints.yaml`. 0 links added, 0 removed, all seven printed links heavier, servos unchanged.
   Printed mass 0.902 to 0.956 kg, +6.0%; the solid bound stays 1.332 kg because the solid is not a
   print assumption. The effort check moves with it: 0.652 to 0.687 N m on `joint_2`, 22% to 23% of
   the servo's stall.
7. **2:35, the live viewer (only if a display is at hand).** `python -m robocad.demo so101 --bundle
   docs/twin/so101/bundle --mode replay` opens the same bundle in the MuJoCo viewer and replays the
   trajectory the page bakes. **Replay only, not hold.** Holding a commanded pose fails on this
   bundle, and the failure is kept rather than hidden: 573 mrad steady-state error with every joint
   pinned at its 2.942 N m force limit, because the gain assumption `kp` = 20 asks for 10 N m to take
   a 0.5 rad step. `docs/twin/so101/live_hold.md` has the per-joint numbers.
8. **2:45, calibration and what we need.** Twin panel: four of five identification rungs recover
   their planted values. The fifth cannot, and the page says why: a 4096-count encoder is 1.53 mrad,
   the servo is 998 N m per rad, so position quantisation is 1.53 N m of torque noise against a
   0.15 N m friction signal. **A motor-current channel takes that SNR from 0.10 to 4.48.** That is
   the ask: three excitation runs and one held-out, with the servo load channel logged.

## Real versus synthetic

| Artefact | Status |
|---|---|
| SO-101 CAD, URDF, MJCF | Real, third party, Apache-2.0, pinned at `a758567` |
| Compiled bundle, checks, comparison, torque | Real output of the compiler on that CAD |
| Page, film | Rendered from the compiled bundle and its report |
| Synthetic twin preview and rungs | **SYNTHETIC.** Planted parameters in simulation; no hardware |
| Live viewer | Local MuJoCo viewer against the same bundle |

Nothing here is a hardware measurement. No robot was commanded.

## Known limits

- Joint origins require the zero-pose conventions to compare at all; a naive comparison reports
  errors of several centimetres that do not exist.
- Printed masses are a model built on two stated assumptions, not measurements.
- `self_collision` fails for a simulator-geometry reason, and the check is not softened.
- The identification result is a method validation on synthetic data, and it stops at the rung where
  the data runs out of information.

## Mesh resolution

The bundle carries full-resolution visual meshes: **620,093 triangles** across 259 meshes, and that stays the source of truth. This page is a build-time decimation of them: **533,262 triangles**, each mesh reduced toward a 3000-triangle budget (the largest mesh in the payload carries 3370). The ratio is **86.0%** of the bundle's figure.

The two numbers measure different things and neither replaces the other. The bundle's count is the geometry the compiled model actually holds; the page's count is what this copy renders. No decimated mesh is ever written back into the bundle: the reduction happens here, at packaging time, and the bundle you compile is the bundle you get.
